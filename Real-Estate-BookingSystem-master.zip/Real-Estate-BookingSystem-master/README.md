# Real-Estate-BookingSystem
WCF service oriented Web application for booking apartments for end users.

5 Web Services were developed in Homework3, which are used subsequently in Hw5.
Data Caching is used to store data item in the cache.
Used Session or cookie in keeping state information of atleast one data item.
